import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)

# Define members and contribution patterns
members = {
    "M001": {"amount": 500, "freq": "Monthly"},
    "M002": {"amount": 300, "freq": "Monthly"},
    "M003": {"amount": 200, "freq": "Weekly"},
    "M004": {"amount": 1000, "freq": "Quarterly"},
    "M005": {"amount": 400, "freq": "Monthly"},
}

# Generate dates
dates_monthly = pd.date_range(start="2026-01-01", periods=12, freq="MS")
dates_weekly = pd.date_range(start="2026-01-01", periods=48, freq="W")
dates_quarterly = pd.date_range(start="2026-01-01", periods=5, freq="3MS")

# Build dataset
rows = []

for member, info in members.items():
    if info["freq"] == "Monthly":
        balance = 0
        for d in dates_monthly:
            contrib = info["amount"]
            withdraw = np.random.choice([0, 100, 200, 300], p=[0.7, 0.1, 0.1, 0.1])
            balance += contrib - withdraw
            balance = max(balance, 0)  # safeguard
            rows.append([member, d, contrib, info["freq"], withdraw, balance])

    elif info["freq"] == "Weekly":
        balance = 0
        for d in dates_weekly:
            contrib = info["amount"]
            withdraw = np.random.choice([0, 50, 100, 200], p=[0.6, 0.2, 0.1, 0.1])
            balance += contrib - withdraw
            balance = max(balance, 0)
            rows.append([member, d, contrib, info["freq"], withdraw, balance])

    elif info["freq"] == "Quarterly":
        balance = 0
        for d in dates_quarterly:
            contrib = info["amount"]
            withdraw = np.random.choice([0, 500], p=[0.7, 0.3])
            balance += contrib - withdraw
            balance = max(balance, 0)
            rows.append([member, d, contrib, info["freq"], withdraw, balance])

# Save to CSV
df = pd.DataFrame(rows, columns=["member_id","date","contribution_amount","contribution_frequency","withdrawal_amount","balance"])
df.to_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\stokvel_dataset.csv", index=False)

print("Dataset generated successfully with", len(df), "rows.")


