import pandas as pd
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
import os

# Step 1: Load dataset
df = pd.read_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\stokvel_dataset.csv")

# Step 2: Convert date column to datetime and sort
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values(by=["member_id", "date"])

# Step 3: Modular cleaning + anomaly logging
def prepare_member_data(df, member_id, anomaly_log="C:\\Users\\v iva\\Desktop\\Stokvel\\data\\anomalies_log.csv"):
    """
    Cleans and prepares data for a specific member before forecasting.
    Ensures numeric balance, handles missing values, sets frequency,
    and logs anomalies (sudden withdrawals or missing months) to a CSV file.
    """
    member_data = df[df['member_id'] == member_id].copy()

    # Convert balance to numeric
    member_data['balance'] = pd.to_numeric(member_data['balance'], errors='coerce')

    # Handle missing values
    member_data['balance'].fillna(method='ffill', inplace=True)
    member_data.dropna(subset=['balance'], inplace=True)

    # Set date as index and add frequency
    member_data.set_index('date', inplace=True)
    member_data = member_data.asfreq('MS')  # Monthly frequency

    # Fill any gaps created by frequency alignment
    member_data['balance'].interpolate(method='linear', inplace=True)

    # --- Anomaly detection ---
    anomalies = []

    # 1. Sudden withdrawals (drop > 30% compared to previous month)
    diffs = member_data['balance'].diff()
    for date, change in diffs.items():
        prev_balance = member_data['balance'].shift(1).loc[date]
        if change < 0 and prev_balance and abs(change) > 0.3 * prev_balance:
            anomalies.append([member_id, date.date(), "Sudden Drop", change])

    # 2. Missing months (NaN before interpolation)
    missing_months = member_data[member_data['balance'].isna()].index
    for date in missing_months:
        anomalies.append([member_id, date.date(), "Missing Month", None])

    # --- Log anomalies to CSV ---
    if anomalies:
        anomalies_df = pd.DataFrame(anomalies, columns=["member_id", "date", "anomaly_type", "value"])
        if os.path.exists(anomaly_log):
            anomalies_df.to_csv(anomaly_log, mode='a', header=False, index=False)
        else:
            anomalies_df.to_csv(anomaly_log, index=False)

        print(f"\nAnomalies logged for {member_id}:")
        for a in anomalies:
            print(" -", a)
    else:
        print(f"\nNo anomalies detected for {member_id}.")

    return member_data, anomalies

# Step 4: Forecast per member + dashboard
members = df['member_id'].unique()
dashboard_records = []

for member in members:
    member_data, anomalies = prepare_member_data(df, member)

    # Train-test split
    train = member_data['balance'][:-2]
    test = member_data['balance'][-2:]

    # Holt-Winters model
    hw_model = ExponentialSmoothing(train, trend="add", seasonal=None)
    hw_fit = hw_model.fit()
    hw_forecast = hw_fit.forecast(len(test))

    # ARIMA model
    arima_model = ARIMA(train, order=(1,1,1))  # (p,d,q) can be tuned
    arima_fit = arima_model.fit()
    arima_forecast = arima_fit.forecast(len(test))

    # --- Evaluation metrics ---
    hw_rmse = np.sqrt(mean_squared_error(test, hw_forecast))
    arima_rmse = np.sqrt(mean_squared_error(test, arima_forecast))

    hw_mae = mean_absolute_error(test, hw_forecast)
    arima_mae = mean_absolute_error(test, arima_forecast)

    hw_mape = np.mean(np.abs((test - hw_forecast) / test)) * 100
    arima_mape = np.mean(np.abs((test - arima_forecast) / test)) * 100

    hw_aic = getattr(hw_fit, "aic", None)  # Holt-Winters may not always expose AIC
    arima_aic = arima_fit.aic
    arima_bic = arima_fit.bic

    # Decide best model
    best_model = "Holt-Winters" if hw_rmse < arima_rmse else "ARIMA"

    print(f"\nForecast for {member}:")
    print("Holt-Winters → RMSE:", hw_rmse, "MAE:", hw_mae, "MAPE:", hw_mape, "AIC:", hw_aic)
    print("ARIMA        → RMSE:", arima_rmse, "MAE:", arima_mae, "MAPE:", arima_mape, "AIC:", arima_aic, "BIC:", arima_bic)
    print("Best Model:", best_model)

    # Add to dashboard records
    dashboard_records.append([
        member, hw_rmse, arima_rmse,
        hw_mae, arima_mae,
        hw_mape, arima_mape,
        hw_aic, arima_aic, arima_bic,
        len(anomalies), best_model
    ])

    # Plot results
    if plt is not None:
        plt.figure(figsize=(10,6))
        plt.plot(member_data['balance'], label="Actual Balance", marker="o")
        plt.plot(test.index, hw_forecast, label="Holt-Winters Forecast", marker="x")
        plt.plot(test.index, arima_forecast, label="ARIMA Forecast", marker="s")

        # Highlight anomalies on the plot
        if anomalies:
            for a in anomalies:
                anomaly_date = pd.to_datetime(a[1])
                if anomaly_date in member_data.index:
                    plt.scatter(anomaly_date, member_data.loc[anomaly_date, 'balance'],
                                color="red", marker="D", s=80,
                                label="Anomaly" if "Anomaly" not in plt.gca().get_legend_handles_labels()[1] else "")

        plt.legend()
        plt.title(f"Stokvel Balance Forecasting ({member})")
        plt.xlabel("Date")
        plt.ylabel("Balance")
        plt.grid(True)
        plt.show()
    else:
        print("matplotlib not installed; skipping plot.")

# Step 5: Save dashboard summary
dashboard_df = pd.DataFrame(
    dashboard_records,
    columns=[
        "member_id",
        "HoltWinters_RMSE", "ARIMA_RMSE",
        "HoltWinters_MAE", "ARIMA_MAE",
        "HoltWinters_MAPE", "ARIMA_MAPE",
        "HoltWinters_AIC", "ARIMA_AIC", "ARIMA_BIC",
        "Anomaly_Count", "Best_Model"
    ]
)
dashboard_path = "C:\\Users\\v iva\\Desktop\\Stokvel\\data\\forecasting_dashboard.csv"
dashboard_df.to_csv(dashboard_path, index=False)

print(f"\nDashboard summary saved to {dashboard_path}")
print(dashboard_df)

