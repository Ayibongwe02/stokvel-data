import pandas as pd

# Load dataset
df = pd.read_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\stokvel_dataset.csv")

# Inspect dataset
print("First 5 rows:")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nColumns:", df.columns)
print("\nSummary statistics:")
print(df.describe())
print("\nMissing values per column:")
print(df.isnull().sum())

# Convert date column to datetime
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values(by=["member_id", "date"])

# Ensure numeric conversion
df['balance'] = pd.to_numeric(df['balance'], errors='coerce')

# Handle missing values globally
df['balance'].fillna(method='ffill', inplace=True)
df.dropna(subset=['balance'], inplace=True)

print("\nData types after conversion:")
print(df.dtypes)
print("\nMissing values after cleaning:")
print(df.isnull().sum())

# Prepare one member’s data (example: M001)
member_data = df[df['member_id'] == 'M001'].copy()
member_data.set_index("date", inplace=True)
member_data = member_data.asfreq('MS')  # Monthly frequency
member_data['balance'].fillna(method='ffill', inplace=True)

print("\nPrepared member data:")
print(member_data.head())



