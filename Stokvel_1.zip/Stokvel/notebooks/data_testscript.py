import pandas as pd

df = pd.read_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\stokvel_dataset.csv")
df['date'] = pd.to_datetime(df['date'])
print(df.dtypes)

