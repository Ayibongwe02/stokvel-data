import pandas as pd

# Load both datasets
dashboard = pd.read_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\forecasting_dashboard.csv")
expanded = pd.read_csv("C:\\Users\\ iva\\Desktop\\Stokvel\\data\\stokvel_expanded.csv")


# Merge on MemberID + Date (common keys)
merged = pd.merge(
    expanded,
    dashboard,
    on=["MemberID","Date"],
    how="left"
)

# Save merged dataset
merged.to_csv("forecasting_dashboard_full.csv", index=False)
print("Merged dataset saved as forecasting_dashboard_full.csv")
