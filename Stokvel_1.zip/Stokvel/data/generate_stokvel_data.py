import pandas as pd
import numpy as np
import random

# Parameters
members = ["M001","M002","M003","M004","M005"]
months = pd.date_range("2024-01-01", "2025-12-01", freq="MS")

rows = []

for member in members:
    balance = 0
    region = random.choice(["Johannesburg","Cape Town","Durban"])
    category = random.choice(["Saver","Spender","Irregular"])
    horizon = random.choice(["3-month","6-month","12-month"])
    
    for date in months:
        contribution = random.randint(500,2000)
        withdrawal = random.randint(0,1500)
        balance += contribution - withdrawal
        
        # Forecast balance (slight deviation)
        forecast_balance = balance + random.randint(-200,200)
        
        # Error metrics
        rmse_hw = random.randint(80,200)
        rmse_arima = random.randint(90,220)
        mae = random.randint(60,150)
        mape = round(random.uniform(5,15),2)
        
        # Anomaly logic
        anomaly_count = 0
        anomaly_type = "None"
        if withdrawal > 0.7 * contribution:  # sudden drop
            anomaly_count = 1
            anomaly_type = "Sudden Drop"
        elif contribution == 0:              # missing month
            anomaly_count = 1
            anomaly_type = "Missing Month"
        elif withdrawal > 1200:              # spike
            anomaly_count = 1
            anomaly_type = "Spike"
        
        rows.append([
            member, date.strftime("%Y-%m-%d"), contribution, withdrawal, balance,
            forecast_balance, rmse_hw, rmse_arima, mae, f"{mape}%",
            anomaly_count, anomaly_type, region, category, horizon
        ])

# Build DataFrame
df = pd.DataFrame(rows, columns=[
    "MemberID","Date","Contribution_Amount","Withdrawal_Amount","Balance",
    "Forecast_Balance","RMSE_HoltWinters","RMSE_ARIMA","MAE","MAPE",
    "Anomaly_Count","Anomaly_Type","Region","Member_Category","Forecast_Horizon"
])

# Save to CSV
df.to_csv("C:\\Users\\v iva\\Desktop\\Stokvel\\data\\forecasting_dashboard.csv", index=False)
print("Dataset generated: forecasting_dashboard.csv")

